﻿namespace Cuadrado
{
    public class cuadrado
    {
        public double ladoos;
        public cuadrado(double lado)
        {
            this.ladoos = lado;
        }
        public double area()
        {
            return ladoos * ladoos;
        }

        public double perimetroos()
        {
            return ladoos + ladoos + ladoos + ladoos;
        }
    }
}