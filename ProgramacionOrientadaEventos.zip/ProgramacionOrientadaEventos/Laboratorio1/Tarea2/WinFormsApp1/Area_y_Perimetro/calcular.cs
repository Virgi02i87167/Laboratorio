﻿namespace Area_y_Perimetro
{
    public class calcular
    {
        public double basee;
        public double altura;
        public double lados;
        
        public calcular(double basee, double altura, double lados)
        {
            this.basee = basee;
            this.altura = altura;
            this.lados = lados;
        }
        public double areaa()
        {
            return (basee * altura) / 2;
        }

        public double perimetro()
        {
            return basee + lados + lados;
        }

    }
}