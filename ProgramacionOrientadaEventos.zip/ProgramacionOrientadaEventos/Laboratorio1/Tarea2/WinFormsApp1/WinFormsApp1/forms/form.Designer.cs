﻿namespace WinFormsApp1.forms
{
    partial class form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            baseTextBox = new TextBox();
            button1 = new Button();
            label2 = new Label();
            alturaTextBox = new TextBox();
            resultadoLabel = new Label();
            label3 = new Label();
            ladosTextBox = new TextBox();
            label4 = new Label();
            ladossTextBox = new TextBox();
            cuadradoButton = new Button();
            resultadosLabel = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ActiveCaption;
            label1.Location = new Point(32, 34);
            label1.Name = "label1";
            label1.Size = new Size(154, 15);
            label1.TabIndex = 0;
            label1.Text = "Ingrese la base del triangulo";
            // 
            // baseTextBox
            // 
            baseTextBox.BackColor = SystemColors.Info;
            baseTextBox.Location = new Point(32, 62);
            baseTextBox.Margin = new Padding(3, 2, 3, 2);
            baseTextBox.Name = "baseTextBox";
            baseTextBox.Size = new Size(185, 23);
            baseTextBox.TabIndex = 1;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.Highlight;
            button1.Location = new Point(135, 243);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(82, 22);
            button1.TabIndex = 2;
            button1.Text = "Calcular";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.ActiveCaption;
            label2.Location = new Point(32, 98);
            label2.Name = "label2";
            label2.Size = new Size(160, 15);
            label2.TabIndex = 3;
            label2.Text = "Ingrese la altura del triangulo";
            // 
            // alturaTextBox
            // 
            alturaTextBox.BackColor = SystemColors.Info;
            alturaTextBox.Location = new Point(32, 130);
            alturaTextBox.Margin = new Padding(3, 2, 3, 2);
            alturaTextBox.Name = "alturaTextBox";
            alturaTextBox.Size = new Size(184, 23);
            alturaTextBox.TabIndex = 4;
            // 
            // resultadoLabel
            // 
            resultadoLabel.AutoSize = true;
            resultadoLabel.BackColor = SystemColors.GradientActiveCaption;
            resultadoLabel.Location = new Point(31, 286);
            resultadoLabel.Name = "resultadoLabel";
            resultadoLabel.Size = new Size(0, 15);
            resultadoLabel.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ActiveCaption;
            label3.Location = new Point(32, 168);
            label3.Name = "label3";
            label3.Size = new Size(164, 15);
            label3.TabIndex = 6;
            label3.Text = "Ingrese los lados del triangulo";
            // 
            // ladosTextBox
            // 
            ladosTextBox.BackColor = SystemColors.Info;
            ladosTextBox.Location = new Point(31, 197);
            ladosTextBox.Margin = new Padding(3, 2, 3, 2);
            ladosTextBox.Name = "ladosTextBox";
            ladosTextBox.Size = new Size(185, 23);
            ladosTextBox.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.AppWorkspace;
            label4.Location = new Point(307, 29);
            label4.Name = "label4";
            label4.Size = new Size(166, 15);
            label4.TabIndex = 8;
            label4.Text = "Ingrese los lados del cuadrado";
            // 
            // ladossTextBox
            // 
            ladossTextBox.BackColor = SystemColors.Info;
            ladossTextBox.Location = new Point(309, 62);
            ladossTextBox.Margin = new Padding(3, 2, 3, 2);
            ladossTextBox.Name = "ladossTextBox";
            ladossTextBox.Size = new Size(184, 23);
            ladossTextBox.TabIndex = 9;
            // 
            // cuadradoButton
            // 
            cuadradoButton.BackColor = SystemColors.ActiveCaption;
            cuadradoButton.Location = new Point(404, 98);
            cuadradoButton.Margin = new Padding(3, 2, 3, 2);
            cuadradoButton.Name = "cuadradoButton";
            cuadradoButton.Size = new Size(82, 22);
            cuadradoButton.TabIndex = 10;
            cuadradoButton.Text = "Calcular";
            cuadradoButton.UseVisualStyleBackColor = false;
            cuadradoButton.Click += cuadradoButton_Click;
            // 
            // resultadosLabel
            // 
            resultadosLabel.AutoSize = true;
            resultadosLabel.BackColor = SystemColors.ActiveCaption;
            resultadosLabel.Location = new Point(309, 139);
            resultadosLabel.Name = "resultadosLabel";
            resultadosLabel.Size = new Size(0, 15);
            resultadosLabel.TabIndex = 11;
            // 
            // form
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(700, 338);
            Controls.Add(resultadosLabel);
            Controls.Add(cuadradoButton);
            Controls.Add(ladossTextBox);
            Controls.Add(label4);
            Controls.Add(ladosTextBox);
            Controls.Add(label3);
            Controls.Add(resultadoLabel);
            Controls.Add(alturaTextBox);
            Controls.Add(label2);
            Controls.Add(button1);
            Controls.Add(baseTextBox);
            Controls.Add(label1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "form";
            Text = "form";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox baseTextBox;
        private Button button1;
        private Label label2;
        private TextBox alturaTextBox;
        private Label resultadoLabel;
        private Label label3;
        private TextBox ladosTextBox;
        private Label label4;
        private TextBox ladossTextBox;
        private Button cuadradoButton;
        private Label resultadosLabel;
    }
}