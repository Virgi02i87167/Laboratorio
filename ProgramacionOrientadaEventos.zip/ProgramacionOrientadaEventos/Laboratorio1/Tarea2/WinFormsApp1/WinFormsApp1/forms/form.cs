﻿using System;
using System.Buffers.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Area_y_Perimetro;
using Cuadrado;

namespace WinFormsApp1.forms
{
    public partial class form : Form
    {
        public form()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (double.TryParse(baseTextBox.Text, out double basee) && double.TryParse(alturaTextBox.Text, out double altura) && double.TryParse(ladosTextBox.Text, out double lados))
            {
                calcular Triangulo = new calcular(basee, altura, lados);
                double area = Triangulo.areaa();
                double perimetro = Triangulo.perimetro();

                resultadoLabel.Text = $"El Area del triangulo es: {area}. El perimetro del triangulo es: {perimetro}";
            }
            else
            {
                resultadoLabel.Text = "Ingrese datos validos.";
            }
        }

        private void cuadradoButton_Click(object sender, EventArgs e)
        {
            if (double.TryParse(ladossTextBox.Text, out double ladoos))

            {
                cuadrado Cuadrado = new cuadrado(ladoos);
                double areas = Cuadrado.area();
                double perimetros = Cuadrado.perimetroos();

                resultadosLabel.Text = $"El Area del cuadrado es: {areas}. El perimetro del cuadrado es: {perimetros}";
            }
            else
            {
                resultadosLabel.Text = "Ingrese datos validos.";
            }
        }
    }
}
